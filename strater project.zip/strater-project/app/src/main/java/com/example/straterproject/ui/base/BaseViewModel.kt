package com.example.straterproject.ui.base

import androidx.lifecycle.ViewModel

abstract class BaseViewModel : ViewModel() {
}