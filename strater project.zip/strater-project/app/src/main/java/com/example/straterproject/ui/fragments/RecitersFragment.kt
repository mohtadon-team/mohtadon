package com.example.straterproject.ui.fragments


import androidx.lifecycle.ViewModel
import com.example.straterproject.R
import com.example.straterproject.databinding.FragmentRecitersBinding
import com.example.straterproject.ui.base.BaseFragment

class RecitersFragment : BaseFragment<FragmentRecitersBinding>() {
    override val layoutFragmentId= R.layout.fragment_reciters
    override val viewModel: ViewModel
        get() = TODO("Not yet implemented")


}