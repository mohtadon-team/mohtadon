package com.example.straterproject.utilities

const val baseUrl = "http://mp3quran.net/api/"
const val baseUrl1=" "