package com.example.domain.entity

data class Reciter(
    val Server: String,
    val count: String,
    val id: String,
    val letter: String,
    val name: String,
    val rewaya: String,
    val suras: String
)