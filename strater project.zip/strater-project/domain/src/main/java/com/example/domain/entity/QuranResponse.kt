package com.example.domain.entity

data class QuranResponse(
    val reciters: List<Reciter>
)